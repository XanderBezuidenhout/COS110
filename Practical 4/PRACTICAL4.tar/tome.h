#ifndef TOME_H
#define TOME_H
#include <string>
#include <iostream>

using namespace std;

class tome
{
	private:
		std::string references[5];
		std::string tomeName;
		std::string author;
		int currSpells;
	public:
		tome(std::string name,std::string author);
		tome(std::string name,int tomeSize,std::string author,std::string * initialList);
		~tome();
		int getTomeSize() const;
		std::string getSpell(int i) const;
		std::string getName() const;
		std::string getAuthor() const;
		friend std::ostream& operator<<(std::ostream & output,const tome & t);
		tome operator+(const std::string & add);
		tome operator-(const std::string & sub);
		tome& operator=(const tome & oldTome);
		bool operator>(const tome & t);
		bool operator<(const tome & t);
		bool operator==(const tome & t);
 
};

#endif
