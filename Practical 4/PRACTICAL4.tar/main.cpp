#include <iostream>
#include "tome.h"

using namespace std;

int main() {
    string * aSpells=new string[3];

    aSpells[0]="Crucio";aSpells[1]="Imperio";aSpells[2]="Avada Kedavra";
    tome * A=new tome("Unforgivable Curses",2,"Tom Marvolo Riddle",aSpells);
    tome * B=new tome("Unforgivable Curses Vol. 1",1,"Lord Voldemort",aSpells);
    cout<<"\u001b[31m\u001b[1m++++++++++++++++Tome Containing The First Two Curses++++++++++++++++\u001b[0m"<<endl;
    cout<<*A;
    cout<<"\u001b[31m\u001b[1m++++++++++++++++Tome Containing Only The First Curse++++++++++++++++\u001b[0m"<<endl;
    cout<<*B;
    cout<<"\u001b[31m\u001b[1m++++++++++++++++False++++++++++++++++\u001b[0m"<<endl;
    cout<<A->operator==(*B)<<endl;
    B->operator=(*A);
    cout<<"\u001b[31m\u001b[1m+++++++++++++++++True++++++++++++++++\u001b[0m"<<endl;
    cout<<A->operator==(*B)<<endl;

    tome C("Chadwick's Charms Vol 3","Filius Flitwick");
    C+"Aguamenti";
    C+"Evanesco";
    C+"Incendio";
    C+"Accio";
    C+"Wingardium Leviosa";
    C+"Protego";
    cout<<"\u001b[31m\u001b[1m++++++++++++++++Tome Containing Five Charms++++++++++++++++\u001b[0m"<<endl;
    cout<<C;

    tome D("Chadwick's Charms Vol 1","Chadwick Boot");
    D=C;
    D-"Aguamenti";
    D-"Protego";
    cout<<"\u001b[31m\u001b[1m++++++++++++++++Tome Containing Four Charms++++++++++++++++\u001b[0m"<<endl;
    cout<<D;
    cout<<"\u001b[31m\u001b[1m++++++++++++++++False++++++++++++++++\u001b[0m"<<endl;
    cout<<(A->operator>(*B))<<endl;
    cout<<"\u001b[31m\u001b[1m+++++++++++++++++True++++++++++++++++\u001b[0m"<<endl;
    cout<<(A->operator<(C))<<endl;
    cout<<"\u001b[31m\u001b[1m+++++++++++++++++True++++++++++++++++\u001b[0m"<<endl;
    cout<<(D.operator>(*A))<<endl;
    cout<<"\u001b[31m\u001b[1m++++++++++++++++False++++++++++++++++\u001b[0m"<<endl;
    cout<<(D.operator<(*A))<<endl;
    delete A;
    delete B;
    return 0;
}