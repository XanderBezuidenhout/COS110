#include "tome.h"
#include <string>
#include <cstring>
#include <iostream>

using namespace std;

tome::tome(std::string name,std::string author)
{
	this->tomeName=name;
	this->author=author;
	for (int count=0;count<5;count++)
	{
		references[count]="";
	}
	this->currSpells=0;
}

tome::tome(std::string name,int tomeSize,std::string author,std::string * initialList)
{
	std::string newspell;
	this->tomeName=name;
	if (tomeSize>5)
	{
			this->currSpells=5;
	}
	else
	{
		this->currSpells=tomeSize;
	}
	this->author=author;
	for (int count=0;count<5;count++)
	{
		references[count]="";
	}
	for (int count=0;count<currSpells;count++)
	{	
			if (initialList!=0)
			{
				newspell=initialList[count];
					references[count]=newspell;
			}
	}	
}

tome::~tome()
{
	
}

int tome::getTomeSize() const
{
	return currSpells;
}

std::string tome::getSpell(int i) const
{
	
		//cout<<references[i]<<endl;
			return references[i];
	
	
}

std::string tome::getName() const
{
	return tomeName;
}

std::string tome::getAuthor() const
{
	return author;
}

ostream& operator<<(std::ostream & output,const tome & t)
{
	string temp;
	temp.clear();
	int pos=0;
	
	for (int count=0;count<5;count++)
	{
			if (t.references!=0)
			{
				if (t.getSpell(count)!="")
				{
					temp.append(t.references[count]);
					temp.append(", ");
				}
			}
	}
	if (t.currSpells>0)
	{
		pos=temp.length();
		temp.erase(pos-2,2);
	}
	output<<"Tome Name: "<<t.tomeName<<endl<<"Author: "<<t.author<<endl<<"References: "<<temp<<endl;
	return output;
}

tome tome::operator+(const std::string & add)
{
	//tome newtome(this->tomeName,this->currSpells,this->author,references);
	if (this->currSpells<5)
	{
		for (int count=0;count<5;count++)
		{
			if (this->references[count]=="")
			{
					this->references[count]=add;
					this->currSpells++;
					break;
						return (*this);
			}
		}
	}
	return (*this);
}

tome tome::operator-(const std::string & sub)
{
	//tome newtome=*this;
	for (int count=0;count<5;count++)
	{
		if ((this->references[count])==sub)
		{
				this->references[count]="";
				--(this->currSpells);
				return (*this);
		} 
	}	
	return (*this);
}

tome& tome::operator=(const tome & oldTome)
{
	//tome * newtome=new tome(oldTome.getName(),oldTome.getTomeSize(),oldTome.getAuthor(),0);
	this->tomeName=oldTome.tomeName;
	this->author=oldTome.author;
	this->currSpells=oldTome.currSpells;	
	for (int count=0;count<5;count++)
	{
			this->references[count]=oldTome.references[count];
	}
	return (*this);
}

bool tome::operator>(const tome & t)
{
	return (this->currSpells>t.getTomeSize());
}

bool tome::operator<(const tome & t)
{
	return (this->currSpells<t.getTomeSize());
}

bool tome::operator==(const tome & t)
{
	int freq1,freq2=0;
	//std::string distinct[5];
	bool newspell;
	if (this->currSpells!=t.getTomeSize())
	{
			return false;
	}
	for (int count=0;count<5;count++)
	{
		 freq1=0;
		 freq2=0;
		 for (int index=0;index<5;index++)
		 {
			if (this->references[count]==this->references[index])
			{
					freq1++;
			}
			if (this->references[count]==t.references[index])
			{
					freq2++;
			}
		 }
		 if (freq1!=freq2)
		 {
				return false;
		}
	}
	return true;
}
