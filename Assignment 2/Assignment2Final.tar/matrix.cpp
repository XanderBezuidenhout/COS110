#include "matrix.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

istream& operator>>(istream & input, Matrix & edit)
{
		stringstream ss;
		string line,temp,nothing; //nothing is for the last read that needs to get on 
		line.clear();
		int cols=edit.cols;
		int rows=edit.rows;
		int pos,currrow=0,currcol=0,index=0;
		int values=0;
		double **tempmat;
		tempmat=new double*[rows];
		string totalholder[rows*cols];
		for (int currrow=0;currrow<rows;currrow++)
		{
			tempmat[currrow]=new double[cols];
			for (int currcol=0;currcol<cols;currcol++)
			{
					tempmat[currrow][currcol]=0;
			}
		}
		while ((values<rows*cols))
		{
			input>>temp;
			totalholder[index]=temp;
			values++;
			index++;	
		}
	
		for (int count=0;count<index;count++) //string number:totalholder) replaced for c++98
		{
			line.append(totalholder[count]);
			line.append(" ");	
		}
		line.erase(line.length()-1,1);
			while (!line.empty())
			{
				if (line.find(" ",0)==-1)
				{
						temp=line;
						line.clear();
				}
				else
				{
					pos=line.find(" ",0);
					temp.assign(line,0,pos);
					line.erase(0,pos+1);
				}
				ss.clear();
				ss.str(temp);
				ss>>tempmat[currrow][currcol];
				currcol++;	
				if (currcol==cols)
				{
						currrow++;
						currcol=0;
				}
			}	
	
		edit.setMatrix(tempmat);

		
		for (int rowcounter=0;rowcounter<rows;rowcounter++)
		{
			tempmat[rowcounter]=new double[cols];
			if (tempmat[rowcounter]!=0)
			{
				delete tempmat[rowcounter];
			}
		}
		delete [] tempmat;
		
		return input;
}

ostream& operator<<(ostream & output, const Matrix & outmat)
{
	int cols=outmat.cols;
	int rows=outmat.rows;
		for (int currrow=0;currrow<rows;currrow++)
		{
				for (int currcol=0;currcol<cols;currcol++)
				{
						if (outmat.matrix[currrow]!=0)
						{
								output<<setprecision(3);
								output<<setw(10)<<outmat.matrix[currrow][currcol];
						}
				}
				
					output<<endl;
				
		}
		return output;
}

// constructors
Matrix::Matrix(unsigned r,unsigned c)
{
	rows=r;
	cols=c;
	matrix=new double*[rows];
	for (int currrow=0;currrow<rows;currrow++)
	{
		matrix[currrow]=new double[cols];
		for (int currcol=0;currcol<cols;currcol++)
		{
				matrix[currrow][currcol]=0;
		}
	}
	denominator=1;
	linearDeterminants=0;
	linearSolutions=0;
}

Matrix::Matrix(const Matrix &rhs)
{
	this->denominator=rhs.denominator;
	this->rows=rhs.rows;
	this->cols=rhs.cols;
	this->matrix=new double*[rows];
	for (int currrow=0;currrow<rows;currrow++)
	{
		matrix[currrow]=new double[cols];
		for (int currcol=0;currcol<cols;currcol++)
		{
				matrix[currrow][currcol]=0;
		}
	}
	this->setMatrix(rhs.matrix);
	if (rhs.linearDeterminants==0)
	{
		this->linearDeterminants=0;
	}
	else
	{
			this->linearDeterminants=rhs.linearDeterminants;
	}
	if (rhs.linearSolutions==0)
	{
		this->linearSolutions=0;
	}
	else
	{
		this->linearSolutions=rhs.linearSolutions;
	}
	
	

}
//setter
void Matrix::setMatrix(double **m)
{
	if (m!=0)
	{
		for (int currrow=0;currrow<rows;currrow++)
		{
			for (int currcol=0;currcol<cols;currcol++)
			{
					if ((m[currrow]!=0)&&(matrix[currrow]!=0))
					{
						matrix[currrow][currcol]=m[currrow][currcol];
						//cout<<"success"<<endl;
					}
			}	
		}
	}
	else
	{
		//cout<<"Failed"<<endl;
			return;
	}
}


//destructor
Matrix::~Matrix()
{
		for (int currrow=0;currrow<rows;currrow++)
		{
			if (matrix[currrow]!=0)
			{
				delete matrix[currrow];
			}
		}
		delete [] matrix;
	/*	if (linearSolutions!=0)
		{
				//delete [] linearSolutions;
		}
		if (this->linearDeterminants!=0)
		{
				delete [] linearDeterminants;
		}
	*/
		
}
//getters
unsigned Matrix::getRows() const
{
		return this->rows;
}

unsigned Matrix::getCols() const
{
	return this->cols;
}

//operators
Matrix Matrix::operator[](const unsigned r) const
{
	Matrix tempmatrix(1,cols);
	//cout<<rows<<endl<<r<<endl;
	if ((r<rows))
	{
			//cout<<"yes bro"<<endl;
				for (int currcol=0;currcol<cols;currcol++)
				{
					tempmatrix.matrix[0][currcol]=this->matrix[r][currcol];
					//cout<<this->matrix[r][currcol]<<endl;
				}
	}
	//cout<<tempmatrix<<endl;
	return tempmatrix;
	
		
}

double& Matrix::operator()(const unsigned r, const unsigned c)
{
	
			return (this->matrix[r][c]);
	
}
const double& Matrix::operator()(const unsigned r, const unsigned c) const
{
			return (this->matrix[r][c]);
		
}

const Matrix& Matrix::operator=(const Matrix &rhs)
{
		for (int currrow=0;currrow<rows;currrow++)
		{
			if (matrix[currrow]!=0)
			{
				delete matrix[currrow];
			}
		}
		delete [] matrix;
		this->denominator=rhs.denominator;
	this->rows=rhs.rows;
	this->cols=rhs.cols;
	matrix=new double*[rows];
	for (int currrow=0;currrow<rows;currrow++)
	{
		matrix[currrow]=new double[cols];
		for (int currcol=0;currcol<cols;currcol++)
		{
				matrix[currrow][currcol]=0;
		}
	}
	this->setMatrix(rhs.matrix);
		
	return (*this);
}


/// task 1 end
///task 2 start

//scalar operations

Matrix Matrix::operator*(const double &rhs)
{
	Matrix newmat(*this);
	for (int row=0;row<newmat.getRows();row++)
	{
			for (int col=0;col<newmat.getCols();col++)
			{
					newmat(row,col)*=rhs;
			}
	}
	return newmat;
	
}

Matrix operator*(const double & n, const Matrix &rhs)
{
		Matrix newmat(rhs);
	for (int row=0;row<newmat.getRows();row++)
	{
			for (int col=0;col<newmat.getCols();col++)
			{
					newmat(row,col)*=n;
			}
	}
	return newmat;
}

Matrix& Matrix::operator*=(const double &rhs)
{
	for (int row=0;row<this->getRows();row++)
	{
			for (int col=0;col<this->getCols();col++)
			{
					(*this)(row,col)*=rhs;
			}
	}
	return *this ;
}

Matrix Matrix::operator/(const double &rhs)
{
	Matrix newmat(*this);
	if (rhs!=0)
	{
		for (int row=0;row<newmat.getRows();row++)
		{
				for (int col=0;col<newmat.getCols();col++)
				{
						newmat(row,col)/=rhs;
				}
		}
	}
	else
	{
			cout<<"Error: division by zero"<<endl;
	}
	return newmat;
}

//Matrix with Matrix operations

Matrix Matrix::operator+(const Matrix &rhs)
{
	Matrix newmat(*this);
	if ((newmat.getCols()!=rhs.getCols())||(newmat.getRows()!=rhs.getRows()))
	{
			cout<<"Error: adding matrices of different dimensionality"<<endl;
			return newmat;
	}
	else
	{
		for (int row=0;row<newmat.getRows();row++)
		{
				for (int col=0;col<newmat.getCols();col++)
				{
						newmat(row,col)+=rhs(row,col);
				}
		}
		return newmat;
	}
	
}

Matrix& Matrix::operator+=(const Matrix &rhs)
{
	if (((*this).getCols()!=rhs.getCols())||((*this).getRows()!=rhs.getRows()))
	{
			cout<<"Error: adding matrices of different dimensionality"<<endl;
			return (*this);
	}
	else
	{
		for (int row=0;row<(*this).getRows();row++)
		{
				for (int col=0;col<(*this).getCols();col++)
				{
						(*this)(row,col)+=rhs(row,col);
				}
		}
		return (*this);
	}
}

Matrix Matrix::operator-(const Matrix &rhs)
{
	Matrix newmat(*this);
	if ((newmat.getCols()!=rhs.getCols())||(newmat.getRows()!=rhs.getRows()))
	{
			cout<<"Error: subtracting matrices of different dimensionality"<<endl;
			return newmat;
	}
	else
	{
		for (int row=0;row<newmat.getRows();row++)
		{
				for (int col=0;col<newmat.getCols();col++)
				{
						newmat(row,col)-=rhs(row,col);
				}
		}
		return newmat;
	}
	
}

Matrix& Matrix::operator-=(const Matrix &rhs)
{
	if (((*this).getCols()!=rhs.getCols())||((*this).getRows()!=rhs.getRows()))
	{
			cout<<"Error: subtracting matrices of different dimensionality"<<endl;
			return (*this);
	}
	else
	{
		for (int row=0;row<(*this).getRows();row++)
		{
				for (int col=0;col<(*this).getCols();col++)
				{
						(*this)(row,col)-=rhs(row,col);
				}
		}
		return (*this);
	}
	
}

Matrix Matrix::operator*(const Matrix &rhs)
{
	Matrix lhs(*this);
	double answer;
	if ((lhs.getRows()!=rhs.getCols())||(lhs.getCols()!=rhs.getRows()))
	{
			cout<<"Error: invalid matrix multiplication"<<endl;
			return (*this);
	}
	else
	{
			Matrix newmat(lhs.getRows(),rhs.getCols());
			for (int leftrow=0;((leftrow<lhs.getRows()));leftrow++)
			{
				for (int rightcol=0;rightcol<rhs.getCols();rightcol++)
				{
					answer=0;
					for (int leftcol=0,rightrow=0;((leftcol<lhs.getCols())&&(rightrow<rhs.getRows()));leftcol++,rightrow++)
					{
							answer+=lhs(leftrow,leftcol)*rhs(rightrow,rightcol);
					}
					//cout<<"Now at "<<leftrow<<","<<rightcol<<" which gives answer of "<<answer<<endl;
					newmat(leftrow,rightcol)=answer;
				}	
			}
			return newmat;
	}
}

Matrix& Matrix::operator*=(const Matrix &rhs)
{
	Matrix lhs(*this);
	double answer;
	if ((lhs.getRows()!=rhs.getCols())||(lhs.getCols()!=rhs.getRows()))
	{
			cout<<"Error: invalid matrix multiplication"<<endl;
			return (*this);
	}
	else
	{
			Matrix newmat(lhs.getRows(),rhs.getCols());
			for (int leftrow=0;((leftrow<lhs.getRows()));leftrow++)
			{
				for (int rightcol=0;rightcol<rhs.getCols();rightcol++)
				{
					answer=0;
					for (int leftcol=0,rightrow=0;((leftcol<lhs.getCols())&&(rightrow<rhs.getRows()));leftcol++,rightrow++)
					{
							answer+=lhs(leftrow,leftcol)*rhs(rightrow,rightcol);
					}
					//cout<<"Now at "<<leftrow<<","<<rightcol<<" which gives answer of "<<answer<<endl;
					newmat(leftrow,rightcol)=answer;
				}	
			}
			(*this)=newmat;
			return (*this);
	}
}

Matrix Matrix::operator^(int pow)
{
	if (this->getRows()!=this->getCols())
	{
		cout<<"Error: non-square matrix provided"<<endl;
		return (*this);
	}
	else if (pow<0)
	{
		cout<<"Error: negative power is not supported"<<endl;
		return (*this);
	}
	else
	{
		if (pow==0)
		{
				Matrix newmat(this->getRows(),this->getCols());
				
				for (int row=0,col=0;((row<newmat.getRows())&&(col<newmat.getCols()));row++,col++)
				{
					newmat(row,col)=1; 	
				}
				return newmat;	
			
		}
		else
		{
			Matrix newmat(*this);
			Matrix original(*this);
			for (int multiplied=1;multiplied<=pow-1;multiplied++)
			{
				newmat*=original;
			}
			return newmat;
		}
		
	}
}

Matrix& Matrix::operator^=(int pow)
{
	if (this->getRows()!=this->getCols())
	{
		cout<<"Error: non-square matrix provided"<<endl;
		return (*this);
	}
	else if (pow<0)
	{
		cout<<"Error: negative power is not supported"<<endl;
		return (*this);
	}
	else
	{
		if (pow==0)
		{
				Matrix newmat(this->getRows(),this->getCols());
				
				for (int row=0,col=0;((row<newmat.getRows())&&(col<newmat.getCols()));row++,col++)
				{
					newmat(row,col)=1; 	
				}
				(*this)=newmat;
				return *this;	
			
		}
		else
		{
			Matrix newmat(*this);
			Matrix original(*this);
			for (int multiplied=1;multiplied<=pow-1;multiplied++)
			{
				newmat*=original;
			}
			(*this)=newmat;
			return *this;
		}
		
	}
}

///task 2 end
/// task 3 start

double Matrix::operator~()
{
	double det=0;
	Matrix tempmat(*this);
	int dims[2]={this->getCols(),this->getRows()};
	if ((dims[0]!=dims[1])||(dims[0]+dims[1]>6)||(dims[0]+dims[1]<4))
	{
		cout<<"Error: invalid matrix dimensions"<<endl;
		return 0;

	}
	else
	{
		if (dims[0]==2)
		{
			det=(tempmat(0,0)*tempmat(1,1))-(tempmat(0,1)*tempmat(1,0));
			return det;
		}
		else if (dims[0]==3)
		{
			Matrix Coefficients(tempmat[0]);
			//cout<<Coefficients<<endl;
			Coefficients(0,1)*=-1;
			Matrix * detMats[3];
			for (int matnum=0;matnum<3;matnum++)
			{
				detMats[matnum]=new Matrix(2,2);
				int matcol=0;
				for (int col=0;col<3;col++)
				{
					if (col!=matnum)
					{
						detMats[matnum]->operator()(0,matcol)=tempmat(1,col);
						detMats[matnum]->operator()(1,matcol)=tempmat(2,col);
						
						matcol++;
					}
					
				}
				//cout<<"Mat "<<matnum<<endl;
				//cout<<*detMats[matnum]<<endl;
				det+=Coefficients(0,matnum)*(detMats[matnum]->operator~());
				
			}
			

		}
		return det;
		
	}
	
}

double* Matrix::operator|(Matrix &rhs)
{
	if (this->getCols()!=this->getRows())
	{
		cout<<"Error: non-square matrix provided"<<endl;
		return NULL;
	}
	else if ((this->getRows()+this->getCols()>6)||(this->getRows()+this->getCols()<4))
	{
		cout<<"Error: incorrect number of variables";
		return NULL;
	}
	else if ((rhs.getRows()!=this->getRows())||(rhs.getCols()!=1))
	{
		cout<<"Error: incorrect number of variables";
		return NULL;
	}
	else
	{
		this->linearDeterminants=0;
		if (linearDeterminants==0)
		{
			this->linearDeterminants= new double[rhs.getRows()];
		}
		
		for (int currcol=0;currcol<this->getCols();currcol++)
		{
			Matrix tempmat(*this);
			for (int currrow=0;currrow<tempmat.getRows();currrow++)
			{
				tempmat(currrow,currcol)=rhs(currrow,0);

			}
			this->linearDeterminants[currcol]=~tempmat;
			//cout<<tempmat;

		}
		return this->linearDeterminants;
	}
	
	
}

Matrix Matrix::operator|=(Matrix &rhs)
{
	int numcols=this->getCols();
	int numrows=this->getRows();

	if ((numcols!=numrows)||(numrows+numcols>6)||(numcols+numrows<4))
	{
		cout<<"Error: incorrect number of variables"<<endl;
		return rhs;
	}
	else if ((rhs.cols!=1)||(rhs.rows!=numrows))
	{
		cout<<"Error: incorrect number of variables"<<endl;
		return rhs;
	}
	else
	{
		this->denominator=~(*this);
		if (denominator==0)
		{
			cout<<"Error: division by zero"<<endl;
			return rhs;
		}
		if (this->linearSolutions==0)
		{
			this->linearSolutions=new double[numrows];	
			(*this)|rhs;	
		}
		
		
		Matrix SolMat(numrows,1);
		for (int solcount=0;solcount<numrows;solcount++)
		{
			linearSolutions[solcount]=linearDeterminants[solcount]/denominator;
			
			//cout<<SolMat<<endl;
		}
		for (int solcount=0;solcount<numrows;solcount++)
		{
			SolMat(solcount,0)=linearSolutions[solcount];
		}
		//cout<<SolMat<<endl;
		return SolMat;
	}
	
}