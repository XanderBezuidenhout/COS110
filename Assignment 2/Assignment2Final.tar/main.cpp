#include "matrix.h"
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

int main() {
	cout<<"start task 1 test"<<endl;
    ifstream infile("input.txt");
    ifstream infile2("inputb.txt");
    ifstream outfile("Hmatrix.txt");
    Matrix a(2, 2);
    Matrix b(2, 1);

    cout << a << endl;
    cout << b << endl;

    infile >> a;
   infile2 >> b;
       Matrix c(a);
    cout << a << endl;
    cout << b << endl;
	c(1,1)=a(0,0);
    //cout<<c<<endl;
    c=a[0];
    //cout<<c<<endl;
    //b=a;
   // cout<<a<<endl;
    infile.close();
    infile2.close();
    cout<<a[0]<<endl;
    cout<<a[1]<<endl;
    cout<<b[0]<<endl;
    cout<<b[1]<<endl;
    cout<<"end task 1 test"<<endl;
    cout<<"start task 2 test"<<endl;
    cout<<"c is matrix a times 2.0"<<endl;
    c=a*2.0;
    cout<<c<<endl;
    cout<<"c is itself times 2.0"<<endl;
    c*=2.0;
    cout<<c<<endl;
    cout<<"2.0 times c,without changes"<<endl;
    cout<<2.0*c<<endl;
    cout<<"c divided by 0, without changes "<<endl;
    cout<<c/0<<endl;
    cout<<"c divided by 2.0, no change to c itself"<<endl;
    cout<<c/2.0<<endl;
    cout<<"matrix c plus matrix a, c is unchanged"<<endl;
    cout<<c+a<<endl;
    cout<<"matrix c plus matrix b, incorrect dimensions"<<endl;
    cout<<c+b<<endl;
    cout<<"matrix c plus matrix a, c is changed"<<endl;
    c+=a;
    cout<<c<<endl; 
    cout<<"matrix c minus matrix a,c is unchanged"<<endl;
    cout<<c-a<<endl;
    cout<<"matrix c minus matrix b, incorrect dimensions"<<endl;
    cout<<c-b<<endl;
    cout<<"matrix c minus matrix a, c gets changed"<<endl;
    c-=a;
    cout<<c<<endl;
    cout<<"New matrix D:"<<endl;
    infile.open("Dmatrix.txt");
    infile2.open("Ematrix.txt");
    Matrix D(2,3);
    infile>>D;
    infile.close();
    cout<<D;
    cout<<"New matrix E:"<<endl;
    Matrix E(3,2);
    infile2>>E; 
    infile2.close();
	cout<<E;
	cout<<"D*E unaltered"<<endl;
	cout<<D*E<<endl;
	cout<<"E*D unaltered"<<endl;
	cout<<E*D<<endl;
	cout<<"a*b unaltered"<<endl;
	cout<<a*b<<endl;
	cout<<"D*E D is altered"<<endl;
	D*=E;
	cout<<D<<endl;
	cout<<"E^2 unaltered"<<endl;
	cout<<(E^2)<<endl;
	cout<<"c^2 unaltered"<<endl;
	cout<<(c^2)<<endl;
	cout<<"c^0 unaltered"<<endl;
	cout<<(c^0)<<endl;
	cout<<"c^2 altered"<<endl;
	c^=2;
	cout<<c<<endl;
	cout<<"New matrix F"<<endl;
	infile.open("matrixF.txt");
	Matrix F(3,3);
	infile>>F;
	cout<<F<<endl;
	cout<<"F^2 unaltered"<<endl;
	cout<<(F^2)<<endl;
	cout<<"F^4 altered"<<endl;
	F^=4;
	cout<<F<<endl;
    infile2.open("Gmatrix.txt");\
    cout<<"New Matrix G"<<endl;
    Matrix G(3,3);
    infile2>>G;
    cout<<G<<endl;
    cout<<"G^2"<<endl;
    cout<<(G^2)<<endl;
    //cout<<"G^3"<<endl;
   //cout<<(G^3)<<endl;
  //  cout<<"G^=-2"<<endl;
    //G^=-2;
    //cout<<G<<endl;
    cout<<"Det(G)"<<endl;
    cout<<~G<<endl;
    Matrix RHS(3,1);
    ifstream infile3("Kmatrix.txt");
    infile3>>RHS;
    cout<<"RHS Matrix"<<endl;
    cout<<RHS;
    double * detptr=G|RHS;
    for (int count=0;count<3;count++)
    {
        cout<<detptr[count]<<endl;
    }
    infile3.close();
   // infile3.open("Lmatrix.txt");
   // Matrix L (2,2);
   // infile3>>L;
   // infile3.close();
   // infile3.open("Mmatrix.txt");
   // Matrix RHS2(2,1);
   // infile3>>RHS2;
  //  cout<<"RHS Matrix"<<endl;
   // cout<<RHS2<<endl;
   // detptr=L|RHS2;
   //   for (int count=0;count<2;count++)
   // {
   //     cout<<detptr[count]<<endl;
   // }
    cout<<"Solutions for G"<<endl;
    cout<<(G|=RHS)<<endl;

   /* for (int row=0;row<100;row++)
    {
        for (int col=0; col<100;col++)
        {
            outfile<<"1"<<endl;
        }
        
    }*/

  
//    Matrix H(100,100);
 //   outfile>>H;
  //  cout<<"this is H"<<endl; 
  //  cout<<H<<endl;
   //// cout<<"this is H^0"<<endl;
 //   cout<<(H^0)<<endl;
    return 0;
}
/* Output
0         0
0         0

0
0

12        3
2        -3

15
13
 */
