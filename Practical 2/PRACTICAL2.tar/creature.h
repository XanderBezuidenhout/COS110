#ifndef CREATURE_H
#define CREATURE_H
#include <string>
#include <iostream>

using namespace std;

class creature
{

	private:
	 std::string name;
	 std::string type;
	 int hp;
	 double mana;
	
	public:
		creature();
		creature(creature* c);
		creature(string name,string type,int hp,double mana);
		~creature();
		string getName();
		string getType();
		int getHP();
		double getMana();
		void print();
};
#endif
