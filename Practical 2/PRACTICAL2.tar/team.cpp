#include "team.h"
#include "creature.h"
#include <iostream>
#include <string>

using namespace std;

team::team(string tName,string tID,int sizeTeam,int rank)
{	
	trainerName=tName;
	trainerID=tID;
	this->rank=rank;
	teamLimit=sizeTeam;
	list=new creature*[sizeTeam];
	for (int index=0;index<teamLimit;index++)
	{
			list[index]=0;
	}
	//init list all of null ptr
}

team::team(string tName,string tID,int rank,creature** creatures,int sizeTeam,int currSize)
{	
	
	list=new creature*[sizeTeam];
	trainerName=tName;
	trainerID=tID;
	teamLimit=sizeTeam;
	this->rank=rank;
	for (int index=0;index<currSize;index++)
	{
		if (creatures[index]!= 0)
		{
			list[index]= new creature(creatures[index]);
		}
		else
		{
			list[index]=0;
		}
		
	}
	teamSize=currSize;
	
}

team::~team()
{
		for (int index=0;index<teamLimit;index++)
		{
			if (list[index]!=0)//0 check
			{
				delete list[index];
			}			
		}
		delete [] list;
		
}

int team::addCreature(creature * c)
{
	if (teamSize>=teamLimit)
	{
		return -1;
	}
	else
	{
		for (int index=0;index<teamLimit;index++)
		{ 	
			if (list[index]==0)
			{
					list[index]=c;
					teamSize++;
					return (index);
			}
		}
		//return -1;
	  //loop search for 0 and add creature over there, else -1	
		
		
	}
}

int team::removeCreature(string name)
{
		for (int index=0;index<teamSize;index++)
		{
			//0 check pls
			if (list[index]!=0)
			{
				if (list[index]->getName()==name)
				{
					
					teamSize--;
					delete list[index];
					list[index]=0;
					return index;
				}
			}
				
		}
		return -1;
}

string team::getName()
{
		return trainerName;
}

string team::getID()
{
		return trainerID;
}

int team::getCurrSize()
{
		return teamSize;
}

int team::getLimit()
{
		return teamLimit;
}

void team::printTeam(string s)
{
	int startScan,minIndex,minValue,indextoread=0;
		/*int mana[teamSize],HP[teamSize];
		string names[teamSize];*/
		creature * templist[teamSize];
		creature * temp;
		//loop, lees creature list in by templist NULLPOINTER CHECK BRO
		for (int index=0;index<teamLimit;index++)
		{
				if (list[index]!=NULL)
				{
					//cout<<list[index]<<endl;
					templist[indextoread]=list[index];	
					indextoread++;
					//cout<<templist[indextoread-1]->getName()<<endl;
				}
				
				
		}
		cout<<"Trainer Name: "<<trainerName<<endl;
		cout<<"ID: "<<trainerID<<endl;
		cout<<"Number of Creatures: "<<teamSize<<endl;
		cout<<"Creature Limit: "<<teamLimit<<endl;
		cout<<"Rank: ";
		
		for (int asterisk=0;asterisk<rank;asterisk++)
		{
				cout<<"*";
		}
		cout<<endl;
		
		if (s=="hp")
		{	
			
			
			for (startScan=0;startScan<teamSize;startScan++)
			{
					minIndex=startScan;
					minValue=templist[startScan]->getHP();
					for (int index=startScan+1;index<teamSize;index++)
					{
							if (templist[index]->getHP()<minValue)
							{
									minValue=templist[index]->getHP();
									minIndex=index;
							}
					}
					temp=templist[minIndex];
					templist[minIndex]=templist[startScan];
					templist[startScan]=temp;
					
			}
		}
		else if (s=="m")
		{
			for (startScan=0;startScan<teamSize;startScan++)
			{
					minIndex=startScan;
					minValue=templist[startScan]->getMana();
					for (int index=startScan+1;index<teamSize;index++)
					{
							if (templist[index]->getMana()>minValue)
							{
									minValue=templist[index]->getMana();
									minIndex=index;
							}
					}
					temp=templist[minIndex];
					templist[minIndex]=templist[startScan];
					templist[startScan]=temp;
					
			}
			
		}
		for (int index=0;index<teamSize;index++)
		{
				cout<<templist[index]->getName()<<endl;
		}
		
}
