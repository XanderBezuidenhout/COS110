#ifndef TEAM_H
#define TEAM_H
#include "creature.h"
#include <string>
#include <iostream>

using namespace std;

class creature;

class team
{	
	private:
		creature ** list;
		string trainerName;
		string trainerID;
		int rank;
		int teamLimit;
		int teamSize;	
	public:

		team(string tName,string tID,int sizeTeam,int rank);
		team(string tName,string tID,int rank, creature** creatures,int sizeTeam,int currSize);
		~team();
		int addCreature(creature* c);
		int removeCreature(std::string name);
		string getName();
		string getID();
		int getCurrSize();
		int getLimit();
		void printTeam(std::string s);
};

#endif
