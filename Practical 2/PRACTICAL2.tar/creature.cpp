#include "creature.h"

#include <iostream>
#include <string>


using namespace std;

creature::creature()
{
	
}

creature::creature(creature* c)
{
	if (c!=0)
	{
		name=c->name;
		type=c->type;
		hp=c->hp;
		mana=c->mana;
	}
}

creature::creature(string name,string type,int hp, double mana)
{
		this->name=name;
		this->type=type;
		this->hp=hp;
		this->mana=mana;
}

creature::~creature()
{
	cout<<name<<" deleted"<<endl;	
}


string creature::getName()
{
		return name;
}

string creature::getType()
{
		return type;
}

int creature::getHP()
{
		return hp;
}

double creature::getMana()
{
		return mana;
}

void creature::print()
{
		cout<<"Name: "<<name<<endl;
		cout<<"Type: "<<type<<endl;
		cout<<"HP: "<<hp<<endl;
		cout<<"Mana: "<<mana<<endl;
}
