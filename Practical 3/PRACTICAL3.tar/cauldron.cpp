#include "ingredient.h"
#include "cauldron.h"
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>

cauldron::cauldron(std::string ingredientList,int maxIngredients)
{
	std::string temp,line, name;
	int pos=0,readindex=-1,danger=0,counter=0;
	std::stringstream ss;
	ingredients=new ingredient*[maxIngredients];
	std::ifstream file;
	file.open(ingredientList);
	if(file)
	{
			while ((std::getline(file,line))&&(counter<maxIngredients))
			{
				readindex++;
				ss.clear();
				pos=line.find(',',0);
				name.assign(line,0,pos);
				line.erase(0,pos+1);
				//std::cout
				
				//pos=line.find(',',0);
				ss.str(line);
				ss>>danger;
				ingredients[readindex]=new ingredient(name,danger);
				//std::cout<<ingredients[readindex]->getName()<<" "<<ingredients[readindex]->getDanger()<<std::endl;
				counter++;
			}
			if (readindex)
			{
				numIngredients=readindex+1;
			}
			else
			{
					numIngredients=readindex;
			}
	}
	this->maxIngredients=maxIngredients;
		
}

cauldron::cauldron(const cauldron * oldCauldron)
{
	this->maxIngredients=oldCauldron->getMax();
	this->numIngredients=oldCauldron->getCurr();
	ingredients=new ingredient*[maxIngredients];
	for (int count=0;count<maxIngredients;count++)
	{
			if (oldCauldron->ingredients[count]!=0)
			{
				this->ingredients[count]=new ingredient(oldCauldron->ingredients[count]);
			}
			else
			{
				this->ingredients[count]=0;
			}
	}
	
}

cauldron::~cauldron()
{
		for (int count=0;count<maxIngredients;count++)
		{
				if (ingredients[count]!=0)
				{
						delete ingredients[count];
				}
		}
		delete [] ingredients;
}

void cauldron::operator=(const cauldron& oldCauldron)
{
	if (ingredients!=0)
	{
		delete [] ingredients;
		this->numIngredients=oldCauldron.numIngredients;
		this->maxIngredients=oldCauldron.maxIngredients;
		for (int count=0;count<maxIngredients;count++)
		{
				if ((oldCauldron.ingredients[count])!=0)
				{
					this->ingredients[count]=new ingredient(oldCauldron.ingredients[count]);
				}
				else
				{
					this->ingredients[count]=0;
				}
		}
	}
}

void cauldron::print()
{
	int min,max;
	double average,total=0;
	for (int count=0;count<maxIngredients;count++)
	{
		if (ingredients[count]!=0)
		{
			max=(ingredients[count]->getDanger());
			min=(ingredients[count]->getDanger());
			break;
		}	
	}
	for (int count=0;count<maxIngredients;count++)
	{
			if (ingredients[count]!=0)
			{
				total+=ingredients[count]->getDanger();
				//std::cout<<"total: "<<total<<std::endl;
				if ((ingredients[count]->getDanger()<min))
				{
						min=ingredients[count]->getDanger();
				}
				else if((ingredients[count]->getDanger()>max))	
				{
						max=ingredients[count]->getDanger();
				}
			}
	}
	if (numIngredients!=0)
	{
		average=(total)/(numIngredients*1.0);
	}
	else
	{
			average=0;
	}
	std::cout<<"Number of Ingredients: "<<numIngredients<<std::endl;
	std::cout<<"Average Danger Rating: "<<average<<std::endl;
	std::cout<<"Maximum Danger Rating: "<<max<<std::endl;
	std::cout<<"Minimum Danger Rating: "<<min<<std::endl;
}

int cauldron::getMax() const
{
	return maxIngredients;	
}

int cauldron::getCurr() const
{
	return numIngredients;
}

ingredient* cauldron::getIngredient(int a) const
{
	if (ingredients[a]!=0)
	{
			return (ingredients[a]);
	}
}

int cauldron::addIngredient(std::string in,int dR)
{
	bool added=false;
	for (int count=0;count<maxIngredients;count++)
	{
			if (ingredients[count]==0)
			{
					ingredients[count]=new ingredient(in,dR);
					added=true;
					numIngredients++;
					return count;
					break;
			}
	}
	if (!added)
	{
		ingredient ** temp;
		temp= new ingredient*[maxIngredients];
		for (int count=0;count<maxIngredients;count++)
		{
				temp[count]=new ingredient(ingredients[count]);
				delete ingredients[count];
		}
		delete [] ingredients;
		maxIngredients++;
		numIngredients++;
		this->ingredients=new ingredient*[maxIngredients];
		for (int count=0;count<maxIngredients-1;count++)
		{
				ingredients[count]=new ingredient(temp[count]);
				delete temp[count];
		}
		delete [] temp;
		ingredients[maxIngredients-1]=new ingredient(in,dR);
		return (maxIngredients-1);
	}
	
}

void cauldron::removeIngredient(int in)
{
		if (in>maxIngredients)
		{
				return; //not sure what to return
		}
		else
		{
			if (ingredients[in]!=0)
			{
					delete ingredients[in];
					ingredients[in]=0;
					numIngredients--;
			}
		}
}


void cauldron::distillPotion(cauldron &currCauldron,std::string * list,int numRemove)
{
	int listindex=0;
	bool found;
	while (listindex<numRemove)
	{	
		found=false;
		//std::cout<<"while "<<std::endl;
		for (int count=0;count<currCauldron.getMax();count++)
		{
			if (currCauldron.ingredients[count]!=0)
			{
				if (list[listindex]==currCauldron.ingredients[count]->getName())
				{			
						currCauldron.removeIngredient(count);
						listindex++;	
						found=true;	
						break;			
				}
			}
			//std::cout<<listindex<<std::endl;
				//std::cout<<currCauldron.ingredients[count]->getName()<<std::endl;
		}
		if (!found)
		{
				listindex++;
		}
	}
	for (int count=0;count<numIngredients;count++)
	{
			//std::cout<<currCauldron.ingredients[count]->getName()<<std::endl<<list[1]<<std::endl;
	}
}

void cauldron::listIngredients()
{
		for (int count=0;count<maxIngredients;count++)
		{
				if (ingredients[count]!=0)
				{
						std::cout<<ingredients[count]->getName()<<std::endl;
				}
		}
}









