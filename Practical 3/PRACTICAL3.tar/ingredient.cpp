#include "ingredient.h"
#include <string>

ingredient::ingredient(std::string name,int dangerRating)
{
		this->name=name;
		this->dangerRating=dangerRating;
}

ingredient::ingredient(const ingredient * newIngredient)
{
	if (newIngredient!=0)
	{
		name=newIngredient->name;
		dangerRating=newIngredient->dangerRating;
	}
}

ingredient::ingredient(const ingredient &newIngredient)
{
		name=newIngredient.name;
		dangerRating=newIngredient.dangerRating;
}

ingredient::~ingredient()
{
		
}

int ingredient::getDanger()
{
		return dangerRating;
}
std::string ingredient::getName()
{
		return name;
}
