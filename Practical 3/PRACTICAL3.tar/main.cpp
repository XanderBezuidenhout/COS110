#include <iostream>
#include <string>
#include <sstream>
#include "ingredient.h"
#include "cauldron.h"


using namespace std;

int main()
{
	cauldron * cool;
	cauldron * newcool;
	cauldron * newestcool;
	cool=new cauldron("list.txt",4);
	newcool=new cauldron(cool);
	/*newestcool=newcool;
	cool->print();
	newcool->print();
	newestcool->print();
	cool->listIngredients();
	std::cout<<std::endl;
	newcool->listIngredients();
	std::cout<<std::endl;
	newestcool->listIngredients();*/
	//std::cout<<cool->addIngredient("whore's touch",1000)<<std::endl;
	//cool->print();
	//cool->listIngredients();
	//std::cout<<(cool->getIngredient(3))->getName()<<std::endl;
	//std::string list[2]={"giant toe","whore's touch"};
	//cool->removeIngredient(3);
	//cool->distillPotion(*cool,list,2);
	//	cool->print();
	//cool->listIngredients();
	return 0;
}
