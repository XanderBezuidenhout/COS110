#include <iostream>
#include <string>
#include <sstream>
#include "PalmVein.h"
#include "ContactlessDevice.h"
#include "AccessDevice.h"
#include "Exception.h"

using namespace std;

PalmVein::PalmVein(const string& key,const int& maxStud) : ContactlessDevice()//maxstud is either int or a string, differs in spec at places
{
    this->setKeyword(key);
    this->maxStudents=maxStud;
    this->setStudentDatabase();
   
}

PalmVein::~PalmVein()
{
    this->clearRotor();
    //cout<<"happens here"<<endl;
    delete keyword;
    if (studentDatabase!=0)
    {
         for (int count=0;count<maxStudents;count++)
         {
            if (studentDatabase[count]!=0)
            {
                
                delete [] studentDatabase[count];
               // cout<<"deleted row"<<count<<endl;
            }
        
        }
        //cout<<"happens last"<<endl;
        delete [] studentDatabase;
    }
   
}


string PalmVein::authenticateStudent(const string& codetofind)
{   
    string output;
    output.clear();
    string hashedcode;
    hashedcode.clear(); 
    for (int count=0;count<codetofind.length();count++)
    {
        hashedcode.append(1,hashChar(codetofind[count]));
        //cout<<hashedcode<<endl;
    }
    output.append(hashedcode);
    if (findStudent(codetofind))
    {
        output.append("true");
        return output;
    }
    else
    {
        output.append("false");
        return output;
    }  
}
string PalmVein::registerStudent(const string& codetoenter)
{
    if (currentStudent==maxStudents)
    {
        throw Exception("Student Database is full"); //write to say database full
    }
    else if (findStudent(codetoenter))
    {
        throw Exception("Student already exists");//typo in spec
    }
    else if (codetoenter.length()==0)
    {
        throw Exception("Invalid input");
    }
    else
    {
        string hashedcode;
        hashedcode.clear();
        int charascii;
        
        for (int count=0;count<codetoenter.length();count++)
        {
            charascii=codetoenter[count];
            if (charascii==32)
            {
                throw Exception("Invalid input"); //write in exception class if invalid student num
            }
        }
        //this->setRotor();
        for (int count=0;count<codetoenter.length();count++)
        {
            hashedcode.append(1,hashChar(codetoenter[count]));
        }
        if (studentDatabase==0)
        {
            setStudentDatabase();
        }
        
        studentDatabase[currentStudent][0]=codetoenter;
        studentDatabase[currentStudent][1]=hashedcode;
        currentStudent++;
        return hashedcode;
    }   
}


