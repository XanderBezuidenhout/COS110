#include <iostream>
#include <string>
#include <sstream>
#include "PalmVein.h"
#include "ContactlessDevice.h"
#include "AccessDevice.h"
#include "Exception.h"

using namespace std;

PalmVein::PalmVein(const string& key,const int& maxStud) : ContactlessDevice()//maxstud is either int or a string, differs in spec at places
{
    this->setKeyword(key);
    this->maxStudents=maxStud;
    this->setStudentDatabase();
   
}

PalmVein::~PalmVein()
{
    this->clearRotor();
    //cout<<"happens here"<<endl;
    if (keyword!=NULL)
    {
        delete keyword;
    }
    
    if (studentDatabase!=0)
    {
         for (int count=0;count<maxStudents;count++)
         {
            if (studentDatabase[count]!=0)
            {
                
                delete [] studentDatabase[count];
               // cout<<"deleted row"<<count<<endl;
            }
        
        }
        //cout<<"happens last"<<endl;
        delete [] studentDatabase;
    }
   
}


string PalmVein::authenticateStudent(const string& codetofind)
{   
   return ContactlessDevice::authenticateStudent(codetofind); 
}
string PalmVein::registerStudent(const string& codetoenter)
{
    return ContactlessDevice::registerStudent(codetoenter);
}


