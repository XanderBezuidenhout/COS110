#include <iostream>
#include <string>
#include <cctype>
#include <sstream>
#include <cmath>
#include <memory>
#include <vector>
#include <fstream>

using namespace std;

int GiveRows(string);//give it a textfile name at time
int GiveCols(string);//give it a line at a time
int GiveID(string);//give it a line at a time
void SelectSort(string [], int size);
int main()
{
	int rows=GiveRows("data.txt"),
	smallestID,
	currID,
	prevID;
	ifstream file;
	stringstream ss;
	//cout<<rows<<endl;
	string temp,currline,smallestline,list[rows];
	string** firstarr=new string*[rows];
	file.open("data.txt");
	for (int row=0;row<rows;row++)
	{
		file>>list[row];
	}
	SelectSort(list,rows);
	for (auto out:list)
	{
			cout<<out<<endl;
	}
	
	/*for (int count=0;count<rows;count++)
	{
		file.open("data.txt");
		smallestID=10000000;
			while (file>>currline)
			{
				//cout<<currline<<endl;
				currID=GiveID(currline);
				//cout<<currID<<endl;
				if ((currID<smallestID)&&(prevID<currID))
				{
					smallestline=currline;
					smallestID=currID;
				}
			}
			//cout<<currline<<endl;
		cout<<smallestline<<endl;
		prevID=smallestID;
		file.close();
		//cout<<count<<" loop"<<endl;	
	}*/
	file.close();
	return 0;
}

int GiveRows(string filename)
{
	int rowcount=0;
	string lines;
	ifstream file;
	file.open(filename);
	
		while (file>>lines)
		{
			rowcount++;
		}
	file.close();
	
	//cout<<rowcount<<"rows"<<endl;
	return rowcount;
}

int GiveID(string line)
{
		stringstream ss;
		ss.clear();
		string temp;
		temp.clear();
		int pos=0,ID;
		
		pos=line.find(',',0);
		if (pos>0)
		{
			temp.assign(line,0,pos);
			//cout<<"great"<<endl;
		}
		else
		{
			temp=line;
		}
		//cout<<temp<<endl;
		ss.str(temp);
		ss>>ID;
		//cout<<ID<<endl;
		return ID;
		
}
void SelectSort(string arr[],int size)
{
	int startscan,minindex,minvalue;
	int currID;
	string temp;
	for (startscan=0;startscan<size-1;startscan++)
	{
			minindex=startscan;
			currID=GiveID(arr[startscan]);
			minvalue=currID;
			for(int index=startscan+1;index<size;index++)
			{
				if (GiveID(arr[index])< minvalue)
				{
						minvalue=GiveID(arr[index]);
						minindex=index;
				}
				
			}
			temp=arr[minindex];
			arr[minindex]=arr[startscan];
			arr[startscan]=temp;
	}
}
