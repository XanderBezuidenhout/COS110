#ifndef SOLVER_H
#define SOLVER_H
#include "board.h"
#include <string>

class solver
{
		private:
			board** boards;
		public:
			solver(std::string games);
			~solver();
};
#endif
