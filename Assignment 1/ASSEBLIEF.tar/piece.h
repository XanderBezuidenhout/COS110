#ifndef PIECE_H
#define PIECE_H
#include <string>


class piece
{
	friend class board;
	private:
		std::string pieceType;
		char side;
		int xPos;
		int yPos;
	public:
		piece();
		piece(piece* newPiece);
		piece(std::string pType,char side,int x, int y);
		~piece();
		char getSide();
		int getX();
		int getY();
		void setX(int x);
		void setY(int y);
		void printPiece();	
	friend class board;
};

#endif
