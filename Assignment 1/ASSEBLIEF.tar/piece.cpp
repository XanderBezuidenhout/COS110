#include "piece.h"
#include <iostream>
#include <string>


piece::piece()
{
	
}
piece::piece(piece* newPiece)
{
	if (newPiece !=0)
	{
		pieceType=newPiece->pieceType;
		xPos=newPiece->getX();
		yPos=newPiece->getY();
		side=newPiece->getSide();
	}	
}


piece::piece(std::string pType,char side,int x,int y)
{
	this->pieceType=pType;
	this->side=side;
	xPos=x;
	yPos=y;
	
}

piece::~piece()
{
	
	std::cout<<"("<<xPos<<","<<yPos<<") "<<side<<" "<<pieceType<<" deleted\n";
		
}

int piece::getX()
{
	return xPos;
}

int piece::getY()
{
	return yPos;
}


void piece::setX(int x)
{
	xPos=x;
}

char piece::getSide()
{
	return side;
}

void piece::setY(int y)
{
	yPos=y;
}

void piece::printPiece()
{
	std::cout<<side<<" "<<pieceType<<" at["<<xPos<<","<<yPos<<"]\n";
}
