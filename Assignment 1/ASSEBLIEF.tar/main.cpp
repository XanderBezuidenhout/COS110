#include <iostream>
#include <string>
#include <cctype>
#include <sstream>
#include <cmath>
#include <memory>
#include <vector>
#include <fstream>
#include "board.h"
#include "piece.h"
#include "solver.h"

using namespace std;

int main()
{
	solver * test= new solver("list.txt");
	delete test;
	/*board * first;
	first=new board("game1.txt");
	std::cout<<"Pawn check "<<first->checkIfPieceHasCheck("p",4,4,5,5)<<std::endl; 
	first->determineIfCheckMate();
	delete first;*/
	return 0;
}
