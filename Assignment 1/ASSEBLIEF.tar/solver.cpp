#include "solver.h"
#include "board.h"
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

int numBoards=0;

solver::solver(std::string games)
{
			std::ifstream file;
			std::stringstream ss;
			std::string line;
			board * tempboard;
			int pos,boardindex=-1;
			file.open(games);
			while (getline(file,line))
			{
					numBoards++;
			}
			file.close();
			file.open(games);
			
			std::string boardname[numBoards];
			int priority[numBoards];
				boards =new board*[numBoards];
			
			while (getline(file,line))
			{
				boardindex++;
				pos=line.find(",",0);
				boardname[boardindex]=line.substr(0,pos);
				line.erase(0,pos+1);
				
				ss.clear();
				ss.str(line);
				ss>>priority[boardindex];
				line.clear();				
			}
			
			int lowest,startscan,lowestindex;
			std::string temp;
			
			for (int startscan=0;startscan<numBoards-1;startscan++)
			{
				lowest=priority[startscan];
				lowestindex=startscan;
				
					for (int index=startscan+1;index<numBoards;index++)
					{
							if (priority[index]<lowest)
							{
									lowest=priority[index];
									lowestindex=index;
							}
					}
					priority[lowestindex]=priority[startscan];
					
					temp=boardname[lowestindex];
					tempboard=boards[lowestindex];
					
					//boardname[lowestindex]=boardname[startscan];
					//boards[lowestindex]=boards[startscan];
					
					//boardname[startscan]=temp;
					//boards[startscan]=tempboard;
					priority[startscan]=lowest;
			}
			for (int count=0;count<numBoards;count++)
			{
				boards[count]=new board(boardname[count]);
			}
			for (int count=0;count<numBoards;count++)
			{
				//std::cout<<boardname[count]<<" "<<priority[count]<<std::endl;
					
					std::cout<<"["<<priority[count]<<"] ";
					
					boards[count]->determineIfCheckMate();
				
			}
			
			
			
}

solver::~solver()
{
	if (boards!=0)
	{
		for (int count=0;count<numBoards;count++)
		{
				if (boards[count]!=0)
				{
						delete boards[count];
				}
		}
		delete [] boards;
	}
	std::cout<<"Num Boards Deleted: "<<numBoards<<std::endl;
}
