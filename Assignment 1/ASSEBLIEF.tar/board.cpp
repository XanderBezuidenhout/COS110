#include <string>
#include "piece.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include "board.h"



board::board(std::string pieceList) //given name of textfile to read from, it works
{
	std::string temp,line;
	std::ifstream file;
	int loops=1;
	int pos=0;
	numBlackPieces=0;
	numWhitePieces=0;
	char side;
	std::string type;
	int x,y;
	std::stringstream ss;
	
	file.open(pieceList);
	file>>sideToMove;
	//std::cout<<sideToMove<<std::endl;
	file>>move;
	//std::cout<<move<<std::endl;
	
	blackPieces=new piece*[16];
	whitePieces=new piece*[16];
	//file>>line;
	//std::cout<<line<<std::endl;
	//std::cout<<sideToMove<<std::endl<<move<<std::endl;
	chessboard=new std::string*[8];
	for (int row=0;row<8;row++)
	{
		chessboard[row]=new std::string[8];
		for (int col=0;col<8;col++)
		{
				chessboard[row][col]="-";
		}
	}
	while (file>>line)
	{
		//std::cout<<line<<std::endl;
			//std::cout<<line<<std::endl;
		side=line[0];
		//std::cout<<side<<std::endl;
		line.erase(0,2);
		
		pos=line.find(",",0);
		//std::cout<<pos<<std::endl;
		type.assign(line,0,pos);
		//std::cout<<type<<std::endl;
		line.erase(0,pos+1);
		
		temp=line[0];
		ss.clear();
		ss.str(temp);
		ss>>x;
		line.erase(0,2);
		
		ss.clear();
		temp=line;
		ss.clear();
		ss.str(temp);
		ss>>y;
		line.clear();
		
		//std::cout<<side<<std::endl<<type<<std::endl<<x<<" "<<y<<std::endl;
		if (side=='b')
		{
				blackPieces[numBlackPieces]= new piece(type,side,x,y);
				numBlackPieces++;
				//std::cout<<blacks<<" loops"<<std::endl;
		}			
		else 
		{
				whitePieces[numWhitePieces]=new piece(type,side,x,y);
				numWhitePieces++;
				//std::cout<<whites<<" loops"<<std::endl;
			
				
		}
		chessboard[x][y]=side;
		if (type=="king")
		{
			chessboard[x][y].append("K");
		}
		else
		{
			char symbol;
			symbol=type[0];
			chessboard[x][y].append(1,symbol);
		}
	}
	//std::cout<<"Total pieces "<<whites+blacks<<std::endl;

/*for (int row=0;row<8;row++)
{
		for (int col=0;col<8;col++)
		{
			std::cout<<chessboard[row][col];
		}
		std::cout<<std::endl;
}*/
//applyMove();
//std::cout<<"After move applied: "<<std::endl;
for (int row=0;row<8;row++)
{
		for (int col=0;col<8;col++)
		{
			//std::cout<<chessboard[row][col];
		}
		//std::cout<<std::endl;
}
/*for (int count=0;count<numBlackPieces;count++)
{
		blackPieces[count]->printPiece();
}
for (int count=0;count<numWhitePieces;count++)
{
		whitePieces[count]->printPiece();
}*/
//std::cout<<checkIfPieceHasCheck("rook",0,1,0,0)<<std::endl;
}

board::~board()// this works
{
	for (int count=0;count<numBlackPieces;count++)
	{
		if (blackPieces[count]!=0)
		{
			delete blackPieces[count];
		}
	}
	for (int count=0;count<numWhitePieces;count++)
	{
		if (whitePieces[count]!=0)
		{
				delete whitePieces[count];
		}
	}
	if (chessboard!=0)
	{
		for (int count=0;count<8;count++)
		{
			if (chessboard[count]!=0)
			{
				delete [] chessboard[count];	
			}
		}
		delete [] chessboard;
	}
	std::cout<<"Num Pieces Removed: "<<numWhitePieces+numBlackPieces<<std::endl;
		
}

void board::applyMove()// this works fine
{
	int from[2],fromX,fromY;
	int to[2],toX,toY;
	std::string temp;
	std::stringstream ss;
	
	temp=move[0];
	ss.str(temp);
	ss>>from[0];
	ss.clear();
	
	temp=move[2];
	ss.str(temp);
	ss>>from[1];
	ss.clear();
	
	temp=move[4];
	ss.str(temp);
	ss>>to[0];
	ss.clear();
	
	temp=move[6];
	ss.str(temp);
	ss>>to[1];
	ss.clear();
	//std::cout<<"from: "<<from[0]<<","<<from[1]<<std::endl;
	//std::cout<<"to: "<<to[0]<<","<<to[1]<<std::endl;
	fromX=from[0];
	fromY=from[1];
	toX=to[0];
	toY=to[1];
	if (sideToMove=='b')
	{
		for (int row=0;row<numBlackPieces;row++)
		{
			if ((blackPieces[row][0].getX()==from[0])&&(blackPieces[row][0].getY()==from[1]))
			{ //std::cout<<"MOVED"<<std::endl;
					blackPieces[row]->setX(to[0]);
					blackPieces[row]->setY(to[1]);
					chessboard[toX][toY]=chessboard[fromX][fromY];
					chessboard[fromX][fromY]="-";
					break;
			}
		}
	}
	else
	{
		for (int row=0;row<numWhitePieces;row++)
		{
			if ((whitePieces[row][0].getX()==from[0])&&(whitePieces[row][0].getY()==from[1]))
			{
				//std::cout<<"MOVED"<<std::endl;
					whitePieces[row][0].setX(to[0]);
					whitePieces[row][0].setY(to[1]);
					chessboard[toX][toY]=chessboard[fromX][fromY];
					chessboard[fromX][fromY]="-";
					break;
			}
		}
	}
}

bool board::checkIfPieceHasCheck(std::string pieceType,int xPos,int yPos, int kingX, int kingY)
{
	if (!((xPos==kingX)&&(yPos==kingY)))
	{
		switch (pieceType[0])
		{
			
			case 'p':
			{
				if ((kingX==xPos-1)||(kingX==xPos+1))
				{
						switch (sideToMove)
						{
							case 'b':
							{
								if (kingY==yPos+1)
								{
										return 1;
								}
								else
								{
										return 0;
								}
								break;
							}
							case 'w':
							{
								if (kingY==yPos-1)
								{
										return 1;
								}
								else
								{
										return 0;
								}
							}
						
						}
				}	
				break;	
			}
			
			case 'q':
			{			
						
				if (abs(kingX-xPos)==abs(kingY-yPos))
				{
						return true;
				}
				else if ((kingX==xPos)||(kingY==yPos))
				{
						return true;
				}
				else
				{
						return false;
				}
				
				break;
			}
			
			case 'k':
			{
				if ((abs(kingX-xPos)==2)&&(abs(kingY-yPos)==1))
				{
						return true;
				}
				else if ((abs(kingY-yPos)==2)&&(abs(kingX-xPos)==1))
				{
						return true;
				}
				
				else 
				{
					return false;
				} 
				
				break;
			}
			
			case 'b':
			{
				if (abs(kingX-xPos)==abs(kingY-yPos))
				{
						return true;
				}
				else
				{
						return false;
				}
				break;
			}
			
			case 'r':
			{
				if((kingX==xPos)||(kingY==yPos))
				{
						return true;
				}
				else
				{
						return false;
				}
				
				break;	
			}
			case 'K': 
			{
				if ((abs(kingX-xPos)<=1)&&(abs(kingY-yPos)<=1))  //use in case of checkmate check
				{
						return true;
				}
				else if (abs(kingX-xPos)+abs(kingY-yPos)==1)
				{
						return true;
				}
				else
				{
						return false;
				}
					break;
			}
			
			default:
			{
				return false;	
			}
		}
	}
	else
	{
			return false;
	}
}

void board::determineIfCheckMate()
{
	applyMove();
	for (int row=0;row<7;row++)
	{
			for (int col=0;col<7;col++)
			{
					//std::cout<<chessboard[row][col];
			}
			//std::cout<<std::endl;
	}
	bool canmove=false, spacecheck;
	std::string king,checker,checktype;
	int kingX=-2,kingY=-2,pieceY,pieceX;
	if (sideToMove=='b')
	{
			king="w";
	}
	else
	{
			king="b";
	}
	king.append(1,'K');
	for (int row=0;row<8;row++)
	{
			for (int col=0;col<8;col++)
			{
				if (chessboard[row][col]==king)
				{
						kingX=col;
						kingY=row;
				}
			}
	}
	//std::cout<<king<<" is at "<<kingX<<","<<kingY<<std::endl;
	if ((kingX<0)||(kingX>7)||(kingY<0)||(kingY>7))
	{
			return;
	}
	for (int row=-1;row<2;row++)
	{
		
		for (int col=-1;col<2;col++)
		{
			spacecheck=false;
			//space[row+1][col+1]=false;
				if ((kingY+row>-1)&&(kingY+row<8)&&(kingX+col>-1)&&(kingX+col<8)) //checks if the space is on the board
				{
					//std::cout<<"Looking at space ("<<kingX+col<<","<<kingY+row<<")"<<std::endl;
					if (row+col==0)
					{
							//std::cout<<"checking if king in check"<<std::endl;
					}
					if ((chessboard[kingY+row][kingX+col][0]==king[0])&&(row+col!=0))  //is the piece on the square on same side or can it be taken
					{
							spacecheck=false;
					}	
					else //piece is not on same side or is open space, proceed to check if the spot is in check
					{
						if (sideToMove=='w')
						{
							for (int pieceindex=0;(pieceindex<numWhitePieces)&&(!spacecheck);pieceindex++)
							{
								spacecheck=false;
								if (whitePieces[pieceindex]!=0)
								{
									checker=whitePieces[pieceindex]->pieceType;
									pieceX=whitePieces[pieceindex]->getX();
									pieceY=whitePieces[pieceindex]->getY();
									spacecheck=checkIfPieceHasCheck(checker,pieceY,pieceX,kingY,kingX);
									if (spacecheck)
									{
											//std::cout<<"check"<<" "<<" by "<<checker<<" from "<<pieceX<<","<<pieceY<<" at "<<kingX+col<<","<<kingY+row<<std::endl;
									}
								}	
							}
							
						}
						else if (sideToMove=='b')
						{
							
							for (int pieceindex=0;pieceindex<numBlackPieces;pieceindex++)
							{
								spacecheck=false;
								if (blackPieces[pieceindex]!=0)
								{
									checker=blackPieces[pieceindex]->pieceType;
									pieceX=blackPieces[pieceindex]->getX();
									pieceY=blackPieces[pieceindex]->getY();
									spacecheck=checkIfPieceHasCheck(checker,pieceX,pieceY,kingY,kingX);	
									if (spacecheck)
									{
											//std::cout<<"check"<<" "<<" by "<<checker<<" from "<<pieceX<<","<<pieceY<<" at "<<kingX+col<<","<<kingY+row<<std::endl;
									}
								}	
									
							}
						}	
							/*for (int boardrow=0;(boardrow<8)&&(!spacecheck);boardrow++)//scans board for any piece to check that spot
							{
								spacecheck=false;
									for (int boardcol=0;(boardcol<8)&&(!spacecheck);boardcol++)
									{
										if (chessboard[boardrow][boardcol]!="-") //is there even a piece
										{
											checker=chessboard[boardrow][boardcol];
											checktype=checker[1];
											if ((!spacecheck)&&(checker[0]==sideToMove))	//make sure that any previous piece checking the spot isn't overwritten or isn't same side
											{
												//std::cout<<"Looking to see if "<<checker<<" at ("<<boardcol<<","<<boardrow<<") has check on space ("<<kingX+col<<","<<kingY+row<<")"<<std::endl;
													spacecheck=checkIfPieceHasCheck(checktype,boardcol,boardrow,kingX+col,kingY+row); //just
													
													if (spacecheck)
													{
														//std::cout<<"check"<<" "<<" by "<<checktype<<" at "<<kingX+col<<","<<kingY+row<<std::endl;
														spacecheck=true;
													}
											}
										} 
									}
							}*/
							//space[row+1][col+1]=!spacecheck;
					}			
				}
				else
				{
					spacecheck=true;
				}
				if (!spacecheck)
				{
						//std::cout<<"Move can be made to "<<kingX+col<<","<<kingY+row<<std::endl;
						canmove=true;
				}
		}
	}
	if (canmove) //if the king has space in proximity that is safe, not a checkmate
	{
			std::cout<<"Failed: No Checkmate of "<<king[0]<<" King"<<std::endl;
	}
	else
	{
			std::cout<<"Success: Checkmate of "<<king[0]<<" King at ["<<kingX<<","<<kingY<<"]"<<std::endl;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*std::string typepiece,outpiece,checkpiece,pieceside;
	int kingX,kingY,y,x;
	bool canmove=true;
	bool safe[3][3];
	typepiece.clear();
	outpiece.clear();
	if (sideToMove=='w')
	{
		typepiece.append("b");
		outpiece="b King";
	}
	else 
	{
		typepiece.append("w");
		outpiece="w King";
	}
	typepiece.append("K");
	for (int chessrow=0;chessrow<8;chessrow++)
	{
			for (int chesscol=0;chesscol<8;chesscol++)
			{
					if (chessboard[chessrow][chesscol]==typepiece)
					{
							kingX==chesscol;
							kingY==chessrow;
							break;
					}
			}
	}
	
	
	for (int row=kingY-1,saferow=0;(row<kingY+2)&&(saferow<3);row++,saferow++)
	{
		for (int col=kingX-1,safecol=0;(col<kingX+2)&&(safecol<3);col++,safecol++)
		{
			if (chessboard[row][col][0]==typepiece[0])
			{
				safe[saferow][safecol]=false;	
				continue;
			}
			if ((row>-1)&&(row<8))
			{		
					for (int piecerow=0;piecerow<8;piecerow++)
					{
							for (int piececol=0;piececol<8;piececol++)
							{
									if ((chessboard[piecerow][piececol]!="-")&&(chessboard[piecerow][piececol][0]==sideToMove))
									{
										pieceside=chessboard[piecerow][piececol][1];
										if (checkIfPieceHasCheck(pieceside,piececol,piecerow,kingX,kingY))
										{
												safe[saferow][safecol]=false;
										}
										else
										{
												safe[saferow][safecol]=true;
										}
									}
							}
					}
			}
			else
			{
				safe[saferow][safecol]=false;
				continue;
			}
		}
	}
	for (int row=0;row<3;row++)
	{
			for (int col=0;col<3;col++)
			{
					if (safe[row][col])
					{
							std::cout<<"Success: Checkmate of "<<outpiece<<" at ["<<kingX<<","<<kingY<<"]\n";
							canmove=false;
							break;
					}
			}
	}
	if (!(canmove))
	{
			std::cout<<"Failed: No Checkmate of "<<outpiece<<std::endl;
	}*/
	
}	
